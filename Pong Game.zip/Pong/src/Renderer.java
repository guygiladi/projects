import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class Renderer extends JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//paint the component to the screen and invokes Pong's render method
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Pong.pong.render((Graphics2D)g);
		
	}

	public static long getSerialversiobuid() {
		return serialVersionUID;
	}

}

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.Timer;

public class Pong implements ActionListener, KeyListener {
	
	public static Pong pong;
	public int width=700,height=700;
	public Renderer renderer;
	public Paddle player1;
	public Paddle player2;
	public Ball ball;
	public boolean bot=false;
	public boolean w,s,up,down;
	public int gameStatus=0; // 0=Stopped, 1=Paused , 2= Playing
	public int maxScore=1;
	
	//ctor
	public Pong ()
	{
		Timer timer= new Timer(20,this);
		JFrame jframe= new JFrame("Pong");
		renderer= new Renderer();
		jframe.setSize(width+15, height+35);
		jframe.setVisible(true);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.add(renderer);
		jframe.addKeyListener(this);
		jframe.setResizable(false);
		timer.start();
	}
	
	//the method start the game, place the paddle and the ball at starting positions
	public void start()
	{
		gameStatus= 2;
		player1= new Paddle(this,1);
		player2= new Paddle(this,2);
		ball= new Ball(this);
	}
	
	//the method check the game status and recalculate the paddles+ball location
	public void render(Graphics2D g)
	{
		Color color = new Color(0,153,0);
		g.setColor(color);
		g.fillRect(0, 0, width, height);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); //Smooth the pixels
		
		//game was not started yet
		if(gameStatus == 0 || gameStatus == 3)
		{
			g.setColor(Color.WHITE);
			g.setFont(new Font("Ariel",1,50));
			g.drawString("PONG",width/2-75,50);
			
			g.setColor(Color.WHITE);
			g.setFont(new Font("Ariel",1,30));
			g.drawString("Press Space to play", width/2-150,height/2-25);
			g.drawString("Press Shift to play with Bot", width/2-200 ,height/2+25);
		}
		
		//player1 reach the max score
		if((gameStatus == 2 || gameStatus == 3) && (player1.score == maxScore))
		{
			g.setColor(Color.WHITE);
			g.setFont(new Font("Ariel",1,50));
			g.drawString("Player 1 is the winner!!", width/2-250 ,height/2-75);
			gameStatus=3;
		}
		//player2 reach the max score
		else if((gameStatus == 2 || gameStatus == 3) && (player2.score == maxScore))
		{
			g.setColor(Color.WHITE);
			g.setFont(new Font("Ariel",1,50));
			g.drawString("Player 2 is the winner!!", width/2-250 ,height/2-75);
			gameStatus=3;
		}
		
		//game paused or in play
		if(gameStatus == 2 || gameStatus==1 )
		{	
			g.setColor(Color.WHITE);
			g.setStroke(new BasicStroke(5f));  //thick line
			g.drawLine(width/2, 0, width/2, height);
			
			g.setFont(new Font("Ariel",1,50));
			g.drawString(String.valueOf(player1.score),width/2-110,50);
			g.drawString(String.valueOf(player2.score),width/2+75,50);
			
			g.setStroke(new BasicStroke(2f));  //thin line
			g.drawOval(width/2 - 100,height/2 - 100 , 200, 200);
			
			player1.render(g);
			player2.render(g);
			ball.render(g);
		}
		
		//game paused
		if(gameStatus == 1)
		{
			g.setColor(Color.WHITE);
			g.setFont(new Font("Ariel",1,50));
			g.drawString("PAUSED",width/2-103,height/2-105);
		}
		
	}

	public static void main(String[] args) {
		pong= new Pong();

	}

	//if a key was pressed, and the game's status is in play, repaint the screen
	public void actionPerformed(ActionEvent arg0) {
		
		if(gameStatus == 2)
		{
			update();
		}
		
		renderer.repaint();
	}
	
	//the method check if the players were moved the paddle (up= true, down=false), 
	public void update()
	{
		//player1
		if(w)
		{
			player1.move(true);
		}
		else if(s)
		{
			player1.move(false);
		}
		
		//player2
		if(!bot)
		{
			if(up)
			{
				player2.move(true);
			}
			 if(down)
			{
				player2.move(false);
			}
		}
		
		//bot
		else
		{
			//the bot's paddle must be in the same ball's Y axis
			if(player2.y + player2.height/2 < ball.y)
			{
				player2.move(false);
			}
			
			//the bot's paddle must be in the same ball's Y axis
			if(player2.y + player2.height/2 > ball.y)
			{
				player2.move(true);
			}
		}
		
		ball.update(player1, player2);
	}

	//the method check if there any key event ,update game status if press space
	public void keyPressed(KeyEvent e) {
		
		int id= e.getKeyCode();
		
		if(id== KeyEvent.VK_W)
		{
			w=true;
		}
		
		else if(id== KeyEvent.VK_S)
		{
			s=true;
		}
		
		else if(id== KeyEvent.VK_UP)
		{
			up=true;
		}
		
		else if(id== KeyEvent.VK_DOWN)
		{
			down=true;
		}
		
		else if(id == KeyEvent.VK_SHIFT && gameStatus == 0)
		{
			bot = true;
			start();
		}
		
		else if(id == KeyEvent.VK_SPACE)
		{
			if(gameStatus == 0 || gameStatus == 3)
			{
				start();
				bot = false;
			}
			
			else if(gameStatus == 1)
			{
				gameStatus = 2;
			}
			
			else if(gameStatus == 2)
			{
				gameStatus = 1;
			}
		}
		
		else if(id == KeyEvent.VK_ESCAPE && (gameStatus == 2 || gameStatus == 3))
		{
			gameStatus=0;
		}
		
	
		
	}

	//the method check if there any key released event ,update game status if press space
	public void keyReleased(KeyEvent e) {
		
		int id= e.getKeyCode();
		
		if(id == KeyEvent.VK_W)
		{
			w=false;
		}
		
		else if(id== KeyEvent.VK_S)
		{
			s=false;
		}
		
		else if(id== KeyEvent.VK_UP)
		{
			up=false;
		}
		
		else if(id== KeyEvent.VK_DOWN)
		{
			down=false;
		}
		
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		
		
	}
		

	
		
	
	
		

}

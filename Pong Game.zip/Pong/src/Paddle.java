import java.awt.Color;
import java.awt.Graphics;

public class Paddle {
	
	public int paddleNumber;
	
	public int x,y,width=50,height=250;
	
	public int score;
	
	//ctor, get paddle number and pong instance
	public Paddle(Pong pong,int paddleNumber)
	{
		this.paddleNumber=paddleNumber;
		
		if(paddleNumber==1)
		{
			this.x=0;
		}
		
		else if(paddleNumber==2)
		{
			this.x=pong.width-width;
			
		}
		this.y=pong.height/2 -this.height/2;
	}

	//the method  get x,y coordinate of the paddle and paint it on the screen
	public void render(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(x, y, width, height);
		
		
	}


	public void move(boolean up) {
		
		int speed=35;
		
		if(up)
		{ 
			//check if the paddle don't exceed from the frame ( up frame (0,0) )
			if(y - speed > 0)
			{
				y-=speed;
			}
			else
			{
				y=0;
			}
		}
		else
		{
			//check if the paddle don't exceed from the frame ( down frame (0,height) )
			if(y + height + speed < Pong.pong.height)
			{
				y+=speed;
			}
			else
			{
				y=Pong.pong.height - height ;
			}
		}
		
	}




}

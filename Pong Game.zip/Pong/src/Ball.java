import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Ball {
	
	public int x,y,width=25,height=25;
	private int motionX;
	private int motionY; 
	private Pong pong;
	public int amountOfHits;
	Random random;
	
	//ctor
	public Ball(Pong pong)
	{
		this.pong=pong;
		this.random = new Random();
		
		spawn();
	}
	
	public void render(Graphics g)
	{
		g.setColor(Color.RED);
		g.fillOval(x, y, width, height);
	}
	
	public void update(Paddle paddle1, Paddle paddle2)
	{
		int speed = 5;
		this.x += motionX * speed;
		this.y += motionY * speed;
		
		//if the ball hit the frame 
		if(this.y + height - motionY > pong.height || this.y+ motionY < 0)
		{
			if(this.motionY < 0)
			{
				this.y = 0;
				this.motionY= random.nextInt(4);
				
				if(motionY == 0)
				{
					motionY=1;
				}
			}
			else
			{
				this.motionY= -random.nextInt(4);
				this.y = pong.height - height;
				
				if(motionY == 0)
				{
					motionY = -1;
				}
			}
		}
		
		//hit paddle1
		if(checkCollition(paddle1)== 1)
		{
			this.motionX =  1 + (amountOfHits/5);
			this.motionY = -2 + random.nextInt(4);
			
			if(motionY == 0)
			{
				motionY=1;
			}
			
			amountOfHits++;
		}
		
		//hit paddle2
		else if(checkCollition(paddle2)== 1)
		{
			this.motionX = -1 - (amountOfHits/5);
			this.motionY = -2 + random.nextInt(4);
			
			if(motionY == 0)
			{
				motionY=1;
			}
			
			amountOfHits++;
		}
		
		//hit paddle1 wall
		if(checkCollition(paddle1)== 2)
		{
			paddle2.score++;
			spawn();
		}
		
		//hit paddle2 wall
		else if(checkCollition(paddle2)== 2)
		{
			paddle1.score++;
			spawn();
		}
	}
	
	//the method place the ball in the center of the screen
	public void spawn()
	{
		this.amountOfHits=0;
		this.x=pong.width/2 - this.width/2;
		this.y=pong.height/2 - this.height/2;
		this.motionY= -1 + random.nextInt(4);
		
		//motionY can't be zero (must have a motion)
		if(motionY == 0)
		{
			motionY= 1;
		}
		
		//randomize the direction to right or to the left of the filed
		if(random.nextBoolean())
		{
			motionX= 1;
		}
		else
		{
			motionX= -1;
		}
	}
	
	public int checkCollition(Paddle paddle)
	{
		if(this.x < paddle.x + paddle.width && this.x + width > paddle.x && this.y < paddle.y + paddle.height && this.y + height > paddle.y)
		{
			return 1; //hit one of the paddles
		}
		else if((paddle.x > x + width && paddle.paddleNumber == 1) || (paddle.x < x - width && paddle.paddleNumber == 2))
		{
			return 2; //score
		}
		
		
		return 0; //nothing
	}

}

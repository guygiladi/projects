﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//GenerateRpnString class get input string, parse it to RPN string 
//According to RPN algorithem and calculate the result
namespace $safeprojectname$
{
    class GenerateRpnString
    {
       private Stack<char> stkOp;
       private Stack<float> stkRes;
       private string[] outPut;
       private string inPut;
       private int index;
       private int opCount;

       //ctor get input string and assign it to 'input' var
       public GenerateRpnString(string input)
       {
           setInput(input);
           stkOp = new Stack<char>();
           stkRes = new Stack<float>();
           outPut=new string[input.Length];
           index = 0;
       }


       public void setInput(string inPut)
       {
           this.inPut = inPut;
       }

       public string[] getOutPut()
       {
           return this.outPut;
       }

       public string getInput()
       {
           return this.inPut;
       }

       
        //the method get input string and generate RPN string into outPut var
       public void generateRpn()
       {
           float tmp = 0;
           string tmpStr="";
           Char ch;
           bool minusFlag = false;

           for (int i = 0; i < inPut.Length; i++)
           {
               ch = inPut.ElementAt(i);

               if (i == 0 && ch == '-')
               {
                   minusFlag = true;
                   continue;
               }

               if (!isOperator(ch))
               {
                   tmpStr += ch;

                   //last number in the string
                   if (i == inPut.Length - 1)
                   {
                       tmp = float.Parse(tmpStr);
                       this.outPut[index++] += tmp;
                       continue;
                   }
                   //if the current char is a number and next the char is an operator
                   if (isOperator(inPut.ElementAt(i + 1)))
                   {
                       tmp = float.Parse(tmpStr);

                       if (minusFlag == true)
                       {
                           tmp = tmp * -1;
                           minusFlag = false;
                       }
                       this.outPut[index++] += tmp;
                       tmp = 0;
                       tmpStr = "";
                   }

                   continue;
               }

               checkStack(ch);
               opCount++;

           }

           //pop the remain operators after concate all the numbers
           if (stkOp.Count > 0)
           {
               while(stkOp.Count>0)
                   outPut[index++] += stkOp.Pop();
           }


       }

        
        //return true if the char is operand,false otherwise
       private bool isOperator(char ch)
       {
           if (ch == '+' || ch == '-' || ch == '*' || ch == '/')
               return true;

           return false;
       }
        

       //the method get char and check if push it to the stack or pop it to the outPut string 
       private void checkStack(char ch)
       {
           //if the stack op is empty
           if (stkOp.Count == 0)
           {
               stkOp.Push(ch);
               return;
           }

           if (ch == '+' || ch == '-')
           {
               if (stkOp.Peek() == '+' || stkOp.Peek() == '-')
               {
                   outPut[index++] += stkOp.Pop();
                   stkOp.Push(ch);
                   return;
               }
           }

           if (ch == '+' || ch == '-')
           {
               if (stkOp.Peek() == '*' || stkOp.Peek() == '/')
               {
                   outPut[index++] += stkOp.Pop();
                   stkOp.Push(ch);
                   return;
               }
           }

           if (ch == '*' || ch == '/')
           {
               if (stkOp.Peek() == '*' || stkOp.Peek() == '/')
               {
                   outPut[index++] += stkOp.Pop();
                   stkOp.Push(ch);
                   return;
               }
           }


           if (ch == '*' || ch == '/')
           {
               if (stkOp.Peek() == '+' || stkOp.Peek() == '-')
               {
                   stkOp.Push(ch);
                   return;
               }
           }


       }

       //the method calculate the result of the Rpn string and assign it to the outPut var
       public string calculateRpn()
       {
           float tmpNum;
           float result=0;
           char op;
           string tmpStr, resultStr="";
           float leftOperand, rightOperand;
           Operable[] opArray=new Operable[opCount];

           for (int i = 0,j=0; i < index; i++)
           {
               //the element is an operator
               if (isOperator(outPut[i].ElementAt(0)) && outPut[i].Length==1)
               {
                   op = outPut[i].ElementAt(0);
                   switch (op)
                   {
                       case '+':
                           rightOperand = stkRes.Pop();
                           leftOperand  = stkRes.Pop();
                           opArray[j] = new PlusOp();
                           stkRes.Push(opArray[j++].action(leftOperand, rightOperand));
                                 break;

                       case '-':
                           rightOperand = stkRes.Pop();
                           leftOperand  = stkRes.Pop();
                           opArray[j] = new MinusOp();
                           this.stkRes.Push(opArray[j++].action(leftOperand, rightOperand));
                                  break;

                       case '*':
                           rightOperand = stkRes.Pop();
                           leftOperand  = stkRes.Pop();
                           opArray[j] = new MultipleOp();
                           this.stkRes.Push(opArray[j++].action(leftOperand, rightOperand));
                                 break;

                       case '/':
                           rightOperand = stkRes.Pop();
                           leftOperand  = stkRes.Pop();
                           //divide by zero
                           if (rightOperand == 0)
                           {
                               resultStr = "Error";
                               return resultStr;
                           }
                           opArray[j] = new DivideOp();
                           this.stkRes.Push(opArray[j++].action(leftOperand, rightOperand));
                                  break;
                           

                   }
               }

                //the element is an operand
               else
               {
                   tmpStr = outPut[i];
                   tmpNum = 0;
                   for (int k = 0; k < tmpStr.Length; k++)
                   {
                       tmpNum = float.Parse(tmpStr);
                   }

                   stkRes.Push(tmpNum);
               }
           }

           //final result
           result = this.stkRes.Pop();
           resultStr += result;
           return resultStr;
       }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {

        Student[] newStudentArray= new Student[10];
        Student tmpStudent;
        PasswordToStudent[] newArrayPassword = new PasswordToStudent[10];
        string[] randUserName = {"guy","gal","gil","karin","lior","boaz","dani","zipi","david","meir"};
        string[] randPassword = {"305080103","12345678","abcdef12","abcd1234"};
        int[] idArray = { 305080103,305080095,123456789,1234,565448711,458997823,114213354,232524689,784515895,445652579};

        //the constructor invoke createStudentDB() and createPasswordToStudentDB() method and create arrays of student and password;
        public Form1()
        {
            createStudentDB();
            createPasswordToStudentDB();
            InitializeComponent();

        }

        //the method get username and password input and check they validation
        private void btnOk_Click(object sender, EventArgs e)
        {
            string inputUsername = "";
            string inputPassword = "";

            inputUsername = txtUserName.Text;
            inputPassword = txtPass.Text;

            if (chkInput(inputUsername, inputPassword))
            {
                for (int i = 0; i < newStudentArray.Length; i++)
                    if (newStudentArray[i].getName().Equals(inputUsername))
                        tmpStudent = newStudentArray[i];

                MessageBox.Show("user: " + tmpStudent.getName() + "\n" + "id: " + tmpStudent.getId() + "\n" + "phone: " + tmpStudent.getPhoneNumber() + "\n" + "address: " + tmpStudent.getAddress());
                clear();
            }

            else
            {
                MessageBox.Show("username or password is incorrect!");
                clear();
            }
        }

        //check input user and password, return false if the username is not fount or dont match to the user real pass;
        private bool chkInput(string userName, string password)
        {
            for (int i = 0; i < this.newStudentArray.Length; i++)
            {
                if (userName.Equals(newStudentArray[i].getName()))
                {
                    for (int j = 0; j < this.newArrayPassword.Length; j++)
                    {
                        if (newStudentArray[i].getId() == newArrayPassword[j].getId())
                        {
                            if (password.Equals(newArrayPassword[j].getPassword()))
                                return true;


                            else return false;            //password dont match
                        }
                    }
                }

            }
            return false;                                 //username not found
        }


        //the method create an array of students. the usernames are generate random 
        private Student[] createStudentDB()
        {
            string randUser = "";
            Random random = new Random();

            for (int i = 0; i < this.newStudentArray.Length; i++)
            {
                randUser = randUserName[random.Next(randUserName.Length)];
                newStudentArray[i] = new Student(randUser, "ha sell", "0526989540", idArray[i]);
            }

            return newStudentArray;
        }

        //the method create an array of passwords. the passwords are generate random 
        private PasswordToStudent[] createPasswordToStudentDB()
        {
            string randPass = "";
            Random random = new Random();

            for (int i = 0; i < this.newStudentArray.Length; i++)
            {
                randPass = randPassword[random.Next(randPassword.Length)];
                while (!chkPass(randPass))
                    randPass = randPassword[random.Next(randPassword.Length)];

                newArrayPassword[i] = new PasswordToStudent(newStudentArray[i].getId(), randPass);
                    
            }


            return newArrayPassword;
        }
        
        //the method get password and check if it valid pass.
        private bool chkPass(string pass)
        {
            int countDigit = 0;

            if (pass.Length < 8)
                return false;

            for (int i = 0; i < pass.Length; i++)
                if (pass[i] >= '1' && pass[i] <= '9')
                    countDigit++;
            if (countDigit < 4)
                return false;

            return true;


        }

        private void clear()
        {
            txtPass.Text = "";
            txtUserName.Text = "";
        }
    }
}

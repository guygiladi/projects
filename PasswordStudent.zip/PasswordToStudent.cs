﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class PasswordToStudent
    {
        private int id;
        private string password;

        public PasswordToStudent(int id, string password)
        {
            setId(id);
            setPassword(password);
        }

        private void setId(int id)
        {
            this.id = id;
        }

        public int getId()
        {
            return id;
        }

        private void setPassword(string password)
        {
            this.password = password;
        }

        public string getPassword()
        {
            return password;
        }
    }


}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Student
    {
      private string name;
      private string address;
      private string phoneNumber;
      private int id;

        public Student(string name, string address, string phone, int id)
        {
             setName(name);
             setAddress(address);
             setPhoneNumber(phone);
             setId(id);
        }

        private void setName(string name)
        {
            this.name = name;
        }

        public string getName()
        {
            return name;
        }

        private void setAddress(string address)
        {
            this.address = address;
        }

        public string getAddress()
        {
            return address;
        }

        private void setPhoneNumber(string phone)
        {
            this.phoneNumber = phone;
        }

        public string getPhoneNumber()
        {
            return phoneNumber;
        }

        private void setId(int id)
        {
            this.id = id;
        }

        public int getId()
        {
            return id;
        }

        

    }
}
